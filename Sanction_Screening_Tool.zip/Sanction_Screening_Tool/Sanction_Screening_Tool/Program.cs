﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Sanction_Screening_Tool
{
    class Program
    {
        static HashSet<string> LoadSanctionsList(string filePath)
        {
            var sanctionsList = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var reader = new StreamReader(filePath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (line != null)
                    {
                        line = line.Trim();
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            sanctionsList.Add(line.ToLower());
                        }
                    }
                }
            }
            return sanctionsList;
        }

        static void ScreenTransaction(string transaction, HashSet<string> sanctionsList)
        {
            var sanitizedTransaction = transaction.Trim().ToLower();
            if (sanctionsList.Contains(sanitizedTransaction))
            {
                Console.WriteLine("Alert: Sanctioned entity detected - " + transaction);
            }
            else
            {
                Console.WriteLine("Transaction is clear.");
            }
        }

        static void Main()
        {
            var sanctionsList = LoadSanctionsList("sanctions_list.csv"); // Replace with your sanctions list file
            Console.Write("Enter a transaction or entity name: ");
            var transaction = Console.ReadLine();
            ScreenTransaction(transaction, sanctionsList);
            Console.ReadLine();
        }
    }
}

